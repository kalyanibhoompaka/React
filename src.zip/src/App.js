import Home from "./pages/Home";
import Login from "./components/Login";
import About from "./pages/About";
import Destination_details from "./pages/destination_details";
import Contact from "./pages/contact";
import Travel_destination from "./pages/travel_destination";
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import Journeys from "./pages/Journeys";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import Registration from "./components/Registration";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Navigate } from "react-router-dom";
import config from "./config.json";
import "./App.scss";
import Card1 from "./pages/Card1";
import Card2 from "./pages/Card2";
import Card3 from "./pages/Card3";
import Card4 from "./pages/Card4";
import Card5 from "./pages/Card5";
import Card6 from "./pages/Card6";


function App() {
  return (
    <>
      {config.map((d) => {
        return (
          <Router>
            <Routes>
              <Route path="/" element={<Registration />}></Route>
              <Route path="/Registration" element={<Registration />}></Route>
              <Route path="/card1" element={<Card1 />}></Route>
              <Route path="/card2" element={<Card2 />}></Route>
              <Route path="/card3" element={<Card3 />}></Route>
              <Route path="/card4" element={<Card4 />}></Route>
              <Route path="/card5" element={<Card5 />}></Route>
              <Route path="/card6" element={<Card6 />}></Route>

              <Route path="/home" element={<Home data={d.home} />}></Route>
              <Route path="/about" element={<About data={d.about} />}></Route>
              <Route
                path="/destination_details"
                element={<Destination_details data={d.destination_details} />}
              ></Route>

              <Route
                path="/contact"
                element={<Contact data={d.contact} />}
              ></Route>
              <Route
                path="/travel_destination"
                element={<Travel_destination data={d.travel_destination} />}
              ></Route>
              <Route
                path="/Journeys"
                element={<Journeys data={d.journeys} />}
              ></Route>
              <Route path="/login" element={<Login />}></Route>

              {/* <Route path='/home' element={
                <ProtectedRoute>
                    <Home  data={d.home}/>
                </ProtectedRoute> 
            } /> */}
            </Routes>
          </Router>
        );
      })}

      {/* <Home /> */}
    </>
  );
}

export default App;
