import React from "react";
import PropTypes from "prop-types";

import FiberManualRecordIcon from "@material-ui/icons/FiberManualRecord";

const Status = ({ active, data }) => {
  return (
    <div>
      {data.map((x, index) => (
        <FiberManualRecordIcon
          style={{ fontSize: 12, color: index === active ? "red" : "" }}
        />
      ))}
    </div>
  );
};

Status.propTypes = {
  direction: PropTypes.oneOf(["left", "right"])
};

export default Status;
