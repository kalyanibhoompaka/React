import React from "react";
import PropTypes from "prop-types";

import NavigateBeforeIcon from "@material-ui/icons/NavigateBefore";
import NavigateNextIcon from "@material-ui/icons/NavigateNext";

const Arrow = ({ direction, action }) => {
  const ActionMap = {
    left: { icon: <NavigateBeforeIcon onClick={action} /> },
    right: { icon: <NavigateNextIcon onClick={action} /> }
  };

  return <div className="direction" style={{ cursor: "pointer" }}>{ActionMap[direction].icon}</div>;
};

Arrow.propTypes = {
  direction: PropTypes.oneOf(["left", "right"])
};

export default Arrow;
