import React, { Fragment } from "react";
import "./css/template.scss";
import "./css/bootstrap.min.scss";
import "./css/fa.min.css";
import "./css/owl.carousel.min.scss";
import Header from "../components/Header/Header";
import Footer from "../components/Footer/Footer";
import PlaceCard from "../components/Card/PlaceCards";
import { NavLink } from "react-router-dom";

function Travel_destination(props) {
  let configData = props.data;
  let abcd = configData.card2Details;
  let card2Detailss = abcd.sort((a, b) => {
    if (a.name < b.name) {

      return -1;
    }
  });
  return (
    <>
      <Header />
      <div
        class="bradcam_area bradcam_bg_2"
        style={{ backgroundImage: `url(${configData.bgImage})` }}
      >
        <div class="container">
          <div class="row">
            <div class="col-xl-12">
              <div class="bradcam_text text-center">
                <h3>{configData.traveldestination}</h3>
                <p>{configData.desdestination}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div ClassName="popular_places_area" id="ppakk">
        <div ClassName="container">
          <div ClassName="row">
            <div ClassName="col-lg-6 col-md-6">
              <h1>{configData.ourstory}</h1>
            </div>
            <div ClassName="col-lg-6 col-md-6">
              {configData.desdestination1}
            </div>
          </div>
        </div>
      </div>

      <div className="popular_places_area">
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-lg-6">
              <div className="section_title text-center mb_70">
                <h3>{configData.card2Title}</h3>
                <p>
                  {/* Suffered alteration in some form, by injected humour or good
                    day randomised booth anim 8-bit hella wolf moon beard words. */}
                  {configData.card2Desc}
                </p>
              </div>
            </div>
          </div>
  
          <div className="row">
            
            {card2Detailss.map((a, id) => {
                      var numbers = [1, 2, 3, 4, 5];   
                      const doubleValue = numbers.map((number)=>{   
                          return (number * 2);   
                      });   
                      console.log(doubleValue);   
              return <PlaceCard  key={id} title={a.name} imagePath={a.image}  />;
            })}
          </div>
        </div>
      </div>

      <div className="recent_trip_area">
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-lg-6">
              <div className="section_title text-center mb_70">
                <h3>{configData.Tripstitle}</h3>
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-lg-4 col-md-6">
              <div className="single_trip">
                <div className="thumb">
                  <img src="assets/images/trip/1.png" alt="" />
                </div>
                <div className="info">
                  <div className="date">
                    <span>Oct 12, 2019</span>
                  </div>
                  <NavLink
                    href={() => false}
                    style={({ isActive }) => ({
                      color: isActive ? "red" : "black",
                      height: "20px",
                    })}
                    to="/Journeys"
                  >
                    <h3>{configData.Tripsdesc1}</h3>{" "}
                  </NavLink>
                  {/* <a href="/Journeys" target="_blank">
                    <h3>{configData.Tripsdesc1}</h3>
                  </a> */}
                </div>
              </div>
            </div>
            <div className="col-lg-4 col-md-6">
              <div className="single_trip">
                <div className="thumb">
                  <img src="assets/images/trip/2.png" alt="" />
                </div>
                <div className="info">
                  <div className="date">
                    <span>Oct 12, 2019</span>
                  </div>
                  <NavLink
                    href={() => false}
                    style={({ isActive }) => ({
                      color: isActive ? "red" : "black",
                      height: "20px",
                    })}
                    to="/Journeys"
                  >
                    <h3>{configData.Tripsdesc2}</h3>{" "}
                  </NavLink>
                </div>
              </div>
            </div>
            <div className="col-lg-4 col-md-6">
              <div className="single_trip">
                <div className="thumb">
                  <img src="assets/images/trip/3.png" alt="" />
                </div>
                <div className="info">
                  <div className="date">
                    <span>Oct 12, 2019</span>
                  </div>
                  <NavLink
                    href={() => false}
                    style={({ isActive }) => ({
                      color: isActive ? "red" : "black",
                      height: "20px",
                    })}
                    to="/Journeys"
                  >
                    <h3>{configData.Tripsdesc3}</h3>{" "}
                  </NavLink>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </>
  );
}

export default Travel_destination;
