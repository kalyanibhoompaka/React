import React from "react";
import { Link } from "react-router-dom";
import "./css/template.scss";
import "./css/bootstrap.min.scss";
import "./css/fa.min.css";
import "./css/owl.carousel.min.scss";
import Header from "../components/Header/Header";
import Footer from "../components/Footer/Footer";
import Card from "../components/Card/Card";
import PlaceCard from "../components/Card/PlaceCards";
import config from "../config.json";
import data from "../sliderdb.json";
import Carousel from "../Carousel";
import { NavLink } from "react-router-dom";



function Home(props) {
  // const dataa = ["Banana", "Orange", "Apple", "Mango"];
  // const sort = dataa.sort()
  // console.log(sort)
  // const unsortedLists = [
  //   { name: 'd.name' }
  // ];
  let i=3;
  let configData = props.data;
  let abc = configData.cardDetails;
  let cardDetailss = abc.sort((a, b) => {
    if (a.name < b.name) {
      return -1;
    }
  });
  let abcd = configData.card2Details;
  let card2Detailss = abcd.sort((a, b) => {
    if (a.name < b.name) {
      return -1;
    }
  });

  return (
    <>
      <Header />

      <Carousel list={data} />

      <div className="popular_destination_area">
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-lg-6">
              <div className="section_title text-center mb_70">
                <h3>{configData.cardTitle}</h3>
                <p>{configData.cardDesc}</p>
              </div>
            </div>
          </div>
          <div className="row">
            {cardDetailss.map((d, i) => {
                  { let i=3;
                    for(i=0;i<3;i++)   <Card
                    key={i}
                    title={d.name}
                    linktitle={d.place}
                    imagePath={d.image}
                    link={d.link}
                  />}
              
              return (              
                <Card
                  key={i}
                  title={d.name}
                  linktitle={d.place}
                  imagePath={d.image}
                  link={d.link}
                />
              );
            })}
          </div>
        </div>
      </div>

      <div className="popular_places_area">
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-lg-6">
              <div className="section_title text-center mb_70">
                <h3>{configData.card2Title}</h3>
                <p>
                  {/* Suffered alteration in some form, by injected humour or good
                    day randomised booth anim 8-bit hella wolf moon beard words. */}
                  {configData.card2Desc}
                </p>
              </div>
            </div>
          </div>
          <div className="row">
            {card2Detailss.map((a, i) => {
              return <PlaceCard key={i} title={a.name} imagePath={a.image} />;
            })}
          </div>
        </div>
      </div>
      <div className="video_area video_bg overlay">
        <div className="container">
          <div className="row">
            <div className="col-lg-12">
              <div className="video_wrap text-center">
                <h3>{configData.Videotitle}</h3>
                <div className="video_icon">
                  <a
                    className="popup-video video_play_button"
                    href="{configData.Videopath}"
                    target="_blank"
                  >
                    <i className="fa fa-play"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="travel_variation_area">
        <div className="container">
          <div className="row">
            <div className="col-lg-4 col-md-6">
              <div className="single_travel text-center">
                <div className="icon">
                  <img src="assets/images/svg_icons/1.svg" alt="" />
                </div>
                <h3>{configData.comforttitle}</h3>
                <p>{configData.comfortdesc}</p>
              </div>
            </div>
            <div className="col-lg-4 col-md-6">
              <div className="single_travel text-center">
                <div className="icon">
                  <img src="assets/images/svg_icons/2.svg" alt="" />
                </div>
                <h3>{configData.Luxuries} </h3>
                <p>{configData.Luxuriesdec}</p>
              </div>
            </div>
            <div className="col-lg-4 col-md-6">
              <div className="single_travel text-center">
                <div className="icon">
                  <img src="assets/images/svg_icons/3.svg" alt="" />
                </div>
                <h3> {configData.Travelguide}</h3>
                <p>{configData.Travelguidedesc}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="recent_trip_area">
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-lg-6">
              <div className="section_title text-center mb_70">
                <h3>{configData.Tripstitle}</h3>
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-lg-4 col-md-6">
              <div className="single_trip">
                <div className="thumb">
                  <img src="assets/images/trip/1.png" alt="" />
                </div>
                <div className="info">
                  <div className="date">
                    <span>Oct 12, 2019</span>
                  </div>
                  <NavLink
                    href={() => false}
                    style={({ isActive }) => ({
                      color: isActive ? "red" : "black",
                      height: "20px",
                    })}
                    to="/Journeys"
                  >
                    <h3>{configData.Tripsdesc1}</h3>{" "}
                  </NavLink>
                  {/* <a href="/Journeys" target="_blank">
                    <h3>{configData.Tripsdesc1}</h3>
                  </a> */}
                </div>
              </div>
            </div>
            <div className="col-lg-4 col-md-6">
              <div className="single_trip">
                <div className="thumb">
                  <img src="assets/images/trip/2.png" alt="" />
                </div>
                <div className="info">
                  <div className="date">
                    <span>Oct 12, 2019</span>
                  </div>
                  <NavLink
                    href={() => false}
                    style={({ isActive }) => ({
                      color: isActive ? "red" : "black",
                      height: "20px",
                    })}
                    to="/Journeys"
                  >
                    <h3>{configData.Tripsdesc2}</h3>{" "}
                  </NavLink>
                </div>
              </div>
            </div>
            <div className="col-lg-4 col-md-6">
              <div className="single_trip">
                <div className="thumb">
                  <img src="assets/images/trip/3.png" alt="" />
                </div>
                <div className="info">
                  <div className="date">
                    <span>Oct 12, 2019</span>
                  </div>
                  <NavLink
                    href={() => false}
                    style={({ isActive }) => ({
                      color: isActive ? "red" : "black",
                      height: "20px",
                    })}
                    to="/Journeys"
                  >
                    <h3>{configData.Tripsdesc3}</h3>{" "}
                  </NavLink>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />

      <a
        id="scrollUp"
        href="#top"
        style={{ display: "none", position: "fixed" }}
      >
        <i className="fa fa-angle-double-up"></i>
      </a>
    </>
  );
}

export default Home;

<div ClassName="popular_places_area">
  <div ClassName="container">
    <div ClassName="row">
      <div ClassName="col-lg-4">
        <div ClassName="filter_result_wrap">
          <h3>Filter Result</h3>
          <div ClassName="filter_bordered">
            <div ClassName="filter_inner">
              <div ClassName="row">
                <div ClassName="col-lg-12">
                  <div ClassName="single_select">
                    <select style={{ display: "none" }}>
                      <option data-display="Country">Country</option>
                      <option value="1">Africa</option>
                      <option value="2">canada</option>
                      <option value="4">USA</option>
                    </select>
                    <div ClassName="nice-select" tabindex="0">
                      <span ClassName="current">Country</span>
                      <ul ClassName="list">
                        <li
                          data-value="Country"
                          data-display="Country"
                          ClassName="option selected"
                        >
                          Country
                        </li>
                        <li data-value="1" ClassName="option">
                          Africa
                        </li>
                        <li data-value="2" ClassName="option">
                          canada
                        </li>
                        <li data-value="4" ClassName="option">
                          USA
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div ClassName="col-lg-12">
                  <div ClassName="single_select">
                    <select style={{ display: "none" }}>
                      <option data-display="Travel type">Travel type</option>
                      <option value="1">advance</option>
                      <option value="2">advance</option>
                      <option value="4">premium</option>
                    </select>
                    <div ClassName="nice-select" tabindex="0">
                      <span ClassName="current">Travel type</span>
                      <ul ClassName="list">
                        <li
                          data-value="Travel type"
                          data-display="Travel type"
                          ClassName="option selected"
                        >
                          Travel type
                        </li>
                        <li data-value="1" ClassName="option">
                          advance
                        </li>
                        <li data-value="2" ClassName="option">
                          advance
                        </li>
                        <li data-value="4" ClassName="option">
                          premium
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div ClassName="col-lg-12">
                  <div ClassName="range_slider_wrap">
                    <span ClassName="range">Prise range</span>
                    <div
                      id="slider-range"
                      ClassName="ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                    >
                      <div
                        ClassName="ui-slider-range ui-corner-all ui-widget-header"
                        style={{ left: "12.5%", width: "37.5%" }}
                      ></div>
                      <span
                        tabindex="0"
                        ClassName="ui-slider-handle ui-corner-all ui-state-default"
                        style={{ left: "12.5%" }}
                      ></span>
                      <span
                        tabindex="0"
                        ClassName="ui-slider-handle ui-corner-all ui-state-default"
                        style={{ left: "50%" }}
                      ></span>
                    </div>
                    <p>
                      <input
                        type="text"
                        id="amount"
                        readonly=""
                        style={{
                          border: "0",
                          color: "#7A838B",
                          font_weight: "400",
                        }}
                      />
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div ClassName="reset_btn">
              <button ClassName="boxed-btn4" type="submit">
                Reset
              </button>
            </div>
          </div>
        </div>
      </div>
      <div ClassName="col-lg-8">
        <div ClassName="row">
          <div ClassName="col-lg-6 col-md-6">
            <div ClassName="single_place">
              <div ClassName="thumb">
                <img src="assets/images/place/1.png" alt="" />
                <a href="#" ClassName="prise">
                  $500
                </a>
              </div>
              <div ClassName="place_info">
                <a href="destination_details.html">
                  <h3>California</h3>
                </a>
                <p>United State of America</p>
                <div ClassName="rating_days d-flex justify-content-between">
                  <span ClassName="d-flex justify-content-center align-items-center">
                    <i ClassName="fa fa-star"></i>
                    <i ClassName="fa fa-star"></i>
                    <i ClassName="fa fa-star"></i>
                    <i ClassName="fa fa-star"></i>
                    <i ClassName="fa fa-star"></i>
                    <a href="#">(20 Review)</a>
                  </span>
                  <div ClassName="days">
                    <i ClassName="fa fa-clock-o"></i>
                    <a href="#">5 Days</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div ClassName="col-lg-6 col-md-6">
            <div ClassName="single_place">
              <div ClassName="thumb">
                <img src="assets/images/place/2.png" alt="" />
                <a href="#" ClassName="prise">
                  $500
                </a>
              </div>
              <div ClassName="place_info">
                <a href="destination_details.html">
                  <h3>Korola Megna</h3>
                </a>
                <p>United State of America</p>
                <div ClassName="rating_days d-flex justify-content-between">
                  <span ClassName="d-flex justify-content-center align-items-center">
                    <i ClassName="fa fa-star"></i>
                    <i ClassName="fa fa-star"></i>
                    <i ClassName="fa fa-star"></i>
                    <i ClassName="fa fa-star"></i>
                    <i ClassName="fa fa-star"></i>
                    <a href="#">(20 Review)</a>
                  </span>
                  <div ClassName="days">
                    <i ClassName="fa fa-clock-o"></i>
                    <a href="#">5 Days</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div ClassName="col-lg-6 col-md-6">
            <div ClassName="single_place">
              <div ClassName="thumb">
                <img src="assets/images/place/3.png" alt="" />
                <a href="#" ClassName="prise">
                  $500
                </a>
              </div>
              <div ClassName="place_info">
                <a href="destination_details.html">
                  <h3>London</h3>
                </a>
                <p>United State of America</p>
                <div ClassName="rating_days d-flex justify-content-between">
                  <span ClassName="d-flex justify-content-center align-items-center">
                    <i ClassName="fa fa-star"></i>
                    <i ClassName="fa fa-star"></i>
                    <i ClassName="fa fa-star"></i>
                    <i ClassName="fa fa-star"></i>
                    <i ClassName="fa fa-star"></i>
                    <a href="#">(20 Review)</a>
                  </span>
                  <div ClassName="days">
                    <i ClassName="fa fa-clock-o"></i>
                    <a href="#">5 Days</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div ClassName="col-lg-6 col-md-6">
            <div ClassName="single_place">
              <div ClassName="thumb">
                <img src="assets/images/place/4.png" alt="" />
                <a href="#" ClassName="prise">
                  $500
                </a>
              </div>
              <div ClassName="place_info">
                <a href="destination_details.html">
                  <h3>Miami Beach</h3>
                </a>
                <p>United State of America</p>
                <div ClassName="rating_days d-flex justify-content-between">
                  <span ClassName="d-flex justify-content-center align-items-center">
                    <i ClassName="fa fa-star"></i>
                    <i ClassName="fa fa-star"></i>
                    <i ClassName="fa fa-star"></i>
                    <i ClassName="fa fa-star"></i>
                    <i ClassName="fa fa-star"></i>
                    <a href="#">(20 Review)</a>
                  </span>
                  <div ClassName="days">
                    <i ClassName="fa fa-clock-o"></i>
                    <a href="#">5 Days</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div ClassName="col-lg-6 col-md-6">
            <div ClassName="single_place">
              <div ClassName="thumb">
                <img src="assets/images/place/5.png" alt="" />
                <a href="#" ClassName="prise">
                  $500
                </a>
              </div>
              <div ClassName="place_info">
                <a href="destination_details.html">
                  <h3>California</h3>
                </a>
                <p>United State of America</p>
                <div ClassName="rating_days d-flex justify-content-between">
                  <span ClassName="d-flex justify-content-center align-items-center">
                    <i ClassName="fa fa-star"></i>
                    <i ClassName="fa fa-star"></i>
                    <i ClassName="fa fa-star"></i>
                    <i ClassName="fa fa-star"></i>
                    <i ClassName="fa fa-star"></i>
                    <a href="#">(20 Review)</a>
                  </span>
                  <div ClassName="days">
                    <i ClassName="fa fa-clock-o"></i>
                    <a href="#">5 Days</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div ClassName="col-lg-6 col-md-6">
            <div ClassName="single_place">
              <div ClassName="thumb">
                <img src="assets/images/place/6.png" alt="" />
                <a href="#" ClassName="prise">
                  $500
                </a>
              </div>
              <div ClassName="place_info">
                <a href="destination_details.html">
                  <h3>Saintmartine Iceland</h3>
                </a>
                <p>United State of America</p>
                <div ClassName="rating_days d-flex justify-content-between">
                  <span ClassName="d-flex justify-content-center align-items-center">
                    <i ClassName="fa fa-star"></i>
                    <i ClassName="fa fa-star"></i>
                    <i ClassName="fa fa-star"></i>
                    <i ClassName="fa fa-star"></i>
                    <i ClassName="fa fa-star"></i>
                    <a href="#">(20 Review)</a>
                  </span>
                  <div ClassName="days">
                    <i ClassName="fa fa-clock-o"></i>
                    <a href="#">5 Days</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div ClassName="row">
          <div ClassName="col-lg-12">
            <div ClassName="more_place_btn text-center">
              <a ClassName="boxed-btn4" href="#">
                More Places
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>;
