import React, { Props } from "react";
import { NavLink } from "react-router-dom";

// let items=5;
// let itemList=[];
// let cardnumber=4;
// for(i=0;i<=items;i++)({
//     itemList.push( <li key={index}>{item}</li>)
//   })
// items.forEach((item,index)=>{
//   itemList.push( <li key={index}>{item}</li>)
// })
export default function Card1(props) {


  return (
<ul>
  <div className="col-lg-4 col-md-6">
      <div className="single_destination">
        <div className="thumb">
          <img src={props.imagePath} alt="" />
        </div>
        <div className="content">
          <p className="d-flex align-items-center">
            {" "}
            {props.title}
            <NavLink
              href={() => false}
              style={({ isActive }) => ({
                color: isActive ? "red" : "black",
              })}
              to={props.link}
            >
              {props.linktitle}
            </NavLink>
            {/* <a href={props.link}>{props.linktitle}</a> */}{" "}
          </p>
        </div>
      </div>
    </div>

</ul>
  );
}


