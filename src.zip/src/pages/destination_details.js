import React, { Fragment } from "react";
import Header from "../components/Header/Header";
import Footer from "../components/Footer/Footer";
import { Link } from "react-router-dom";
import "./css/template.scss";
import "./css/bootstrap.min.scss";
import "./css/fa.min.css";
import "./css/owl.carousel.min.scss";
import "./css/style.scss";
import PlaceCard from "../components/Card/PlaceCards";
import Registry from "../pages/Registry";
import "./css/form.scss";
function Destination_details(props) {
  let configData = props.data;

  return (
    <>
      <Header />

      <div ClassName="destination_banner_wrap overlay " id="destink" style={{backgroundImage: `url(${configData.bgImage})`}} >
        <div ClassName="destination_text text-center">
          <h3>
            {configData.detailstitle}
            {/* Saintmartine Iceland */}
          </h3>
          <p>{configData.detailsdesc}</p>
        </div>
      </div>
      <div ClassName="destination_details_info" id="infok">
        <div ClassName="container">
          <div ClassName="row justify-content-center">
            <div ClassName="col-lg-8 col-md-9">
              <div ClassName="destination_info">
                <h3>{configData.Description}</h3>
                <p>{configData.Description1}</p>
                <p>{configData.Description2}</p>
                <div ClassName="single_destination">
                  <h4>{configData.Day1}</h4>
                  <p>{configData.Day1des}</p>
                </div>
                <div ClassName="single_destination">
                  <h4>{configData.Day2}</h4>
                  <p>{configData.Day2des}</p>
                </div>
                <div ClassName="single_destination">
                  <h4>{configData.Day3}</h4>
                  <p>{configData.Day3des}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* <VerticalCarousel data={data.slides} leadingText={data.leadingText} /> */}

      <Registry />
      <div ClassName="popular_places_area" id="ppkk">
        <div ClassName="container">
          <div ClassName="row justify-content-center">
            <div ClassName="col-lg-6">
              <div ClassName="section_title text-center mb_70">
                <h3>{configData.more}</h3>
              </div>
            </div>
          </div>
          <div className="row">
          {configData.card2Details.map((a, i) => {
              return <PlaceCard key={i} title={a.name} imagePath={a.image} />;
            })}
          </div>
        </div>
      </div>

      <Footer />
    </>
  );
}

export default Destination_details;
