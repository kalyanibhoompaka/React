import React, { Fragment, props } from "react";
import Header from "../components/Header/Header";
import Footer from "../components/Footer/Footer";
import { Link } from "react-router-dom";
import "./css/template.scss";
import "./css/bootstrap.min.scss";
import "./css/fa.min.css";
import "./css/owl.carousel.min.scss";
import "./css/style.scss";

function About(props) {
  let configData = props.data;
  // const el = <About name={configData.name} />;
  // console.log(configData.name);
  return (
    <>
      <Header />
      <span>
        <div className="kk">
          <div
            className="bradcam_area bradcam_bg_3"
            style={{backgroundImage: `url(${configData.bgImage})`}}
          >
            <div className="container">
              <div className="row">
                <div className="col-xl-12">
                  <div className="bradcam_text text-center">
                    <h3>{configData.name}</h3>
                    <p>{configData.aboutdesc}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </span>{" "}
      <div ClassName="about_story" id="kk2">
        <div ClassName="container ourk">
          <div ClassName="row">
            <div ClassName="col-lg-12">
              <div ClassName="story_heading">
                <h3>{configData.title}</h3>
              </div>

              <div ClassName="row tory_i">
                <div ClassName="col-lg-11 offset-lg-1">
                  <div ClassName="story_info">
                    <div ClassName="row">
                      <div ClassName="col-lg-9">
                        <p>{configData.ourstory1}</p>
                        <p>{configData.ourstory2}</p>
                      </div>
                    </div>
                  </div>
                  <div ClassName="story_thumb">
                    <div ClassName="row">
                      <div ClassName="col-lg-5 col-md-6">
                        <div ClassName="thumb padd_1">
                          <img src="assets/images/about/1.png" alt="" />
                        </div>
                      </div>
                      <div ClassName="col-lg-6 col-md-6">
                        <div ClassName="thumb">
                          <img src="assets/images/about/2.png" alt="" />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div ClassName="counter_wrap">
                    <div ClassName="row">
                      <div ClassName="col-lg-4 col-md-4">
                        <div ClassName="single_counter text-center">
                          <h3 ClassName="counter">378</h3>
                          <p>Tour has done successfully</p>
                        </div>
                      </div>
                      <div ClassName="col-lg-4 col-md-4">
                        <div ClassName="single_counter text-center">
                          <h3 ClassName="counter">30</h3>
                          <p>Yearly tour arrange</p>
                        </div>
                      </div>
                      <div ClassName="col-lg-4 col-md-4">
                        <div ClassName="single_counter text-center">
                          <h3 ClassName="counter">2263</h3>
                          <p>Happy Clients</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="video_area video_bg overlay">
        <div className="container">
          <div className="row">
            <div className="col-lg-12">
              <div className="video_wrap text-center">
                <h3>{configData.Videotitle}</h3>
                <div className="video_icon">
                  <a
                    className="popup-video video_play_button"
                    href="{configData.Videopath}"
                    target="_blank"
                  >
                    <i className="fa fa-play"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="travel_variation_area">
        <div className="container">
          <div className="row">
            <div className="col-lg-4 col-md-6">
              <div className="single_travel text-center">
                <div className="icon">
                  <img src="assets/images/svg_icons/1.svg" alt="" />
                </div>
                <h3>{configData.comforttitle}</h3>
                <p>{configData.comfortdesc}</p>
              </div>
            </div>
            <div className="col-lg-4 col-md-6">
              <div className="single_travel text-center">
                <div className="icon">
                  <img src="assets/images/svg_icons/2.svg" alt="" />
                </div>
                <h3>{configData.Luxuries} </h3>
                <p>{configData.Luxuriesdec}</p>
              </div>
            </div>
            <div className="col-lg-4 col-md-6">
              <div className="single_travel text-center">
                <div className="icon">
                  <img src="assets/images/svg_icons/3.svg" alt="" />
                </div>
                <h3> {configData.Travelguide}</h3>
                <p>{configData.Travelguidedesc}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="recent_trip_area">
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-lg-6">
              <div className="section_title text-center mb_70">
                <h3>{configData.Tripstitle}</h3>
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-lg-4 col-md-6">
              <div className="single_trip">
                <div className="thumb">
                  <img src="assets/images/trip/1.png" alt="" />
                </div>
                <div className="info">
                  <div className="date">
                    <span>Oct 12, 2019</span>
                  </div>
                  <a href="/Journeys" target="_blank">
                    <h3>{configData.Tripsdesc1}</h3>
                  </a>
                </div>
              </div>
            </div>
            <div className="col-lg-4 col-md-6">
              <div className="single_trip">
                <div className="thumb">
                  <img src="assets/images/trip/2.png" alt="" />
                </div>
                <div className="info">
                  <div className="date">
                    <span>Oct 12, 2019</span>
                  </div>
                  <a href="/Journeys" target="_blank">
                    <h3>{configData.Tripsdesc2}</h3>
                  </a>
                </div>
              </div>
            </div>
            <div className="col-lg-4 col-md-6">
              <div className="single_trip">
                <div className="thumb">
                  <img src="assets/images/trip/3.png" alt="" />
                </div>
                <div className="info">
                  <div className="date">
                    <span>Oct 12, 2019</span>
                  </div>
                  <a href="/Journeys" target="_blank">
                    <h3>{configData.Tripsdesc3}</h3>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
      <a
        id="scrollUp"
        href="#top"
        style={{ display: "none", position: "fixed" }}
      >
        <i className="fa fa-angle-double-up"></i>
      </a>
    </>
  );
}

export default About;
