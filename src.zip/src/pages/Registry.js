import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import "./css/form.scss";

const Registry = () => {
  const [inputValue, setInputValue] = useState(" ");
  const [data, setData] = useState([]);
  const [editIndex, setEditIndex] = useState(-1);
  const [editedValue, setEditedValue] = useState("");
  const [error, setError] = useState(false);
  const [error2, setError2] = useState(false);

  const handleSubmit = (e) => {
    if (inputValue.length <= 0) {
      setError(true);
    } else {
      alert('Email was submitted: ' + inputValue);
      setError(false);
    }
    //         else
    //  alert('A name was submitted: ' + inputValue);
    e.preventDefault();

    if (inputValue.trim() !== "") {
      const newData = [...data, inputValue];

      setData(newData);

      setInputValue("");
    }
  };

  const handleDelete = (index) => {
    const newData = [...data];

    newData.splice(index, 1);

    setData(newData);
  };

  const handleEdit = (index, value) => {
    // if(error)return;

    setEditIndex(index);

    setEditedValue(value);
  };

  const handleUpdate = (index) => {
    const newData = [...data];

    newData[index] = editedValue;

    setData(newData);

    setEditIndex(-1);
  };

  useEffect(() => {
    if (inputValue.length >= 20) {
      setError2(true);
    } else setError2(false);
  }, [inputValue]);

  return (
    <div class="container" className="bodyy">
      <div>
        <h1 className="reg">Register Here</h1> <br />
        <Link to="/home" style={{ color: "red" }}>
          click here go to home
        </Link>
        <br /> <br /> <br /> <br />
        <form onSubmit={handleSubmit}>
          <div>
            <label className="formm">
              ENTER YOUR EMAIL:&nbsp;&nbsp;&nbsp;
              <input
                type="email"
                className="fornamebox"
                maxLength={20}
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
              />
            </label>
            <input
              className="Submit"
              type="Submit"
              value="Submit"
              disabled={error2}
            />
            <br /> <br />
          </div>
          {error && inputValue.length <= 0 ? (
            <span style={{ color: "red" }}>Email should not be blank!!</span>
          ) : (
            ""
          )}
          {error2 ? (
            <span style={{ color: "red" }}>
              name should not exceed more than 20!!
            </span>
          ) : (
            ""
          )}
        </form>
        {/* {error?<span style={{color:"red"}}>name should not be empty and also should not exceed more than 10</span>:null} */}
        {/* {errors? <span style={{color:"red"}}>Error Occurred.</span>:""} */}
        {data.map((entry, index) => (
          <div key={index}>
            {editIndex === index ? (
              <div className="li">
                <input
                  type="email"
                  value={editedValue}
                  onChange={(e) => setEditedValue(e.target.value)}
                />
                &nbsp;&nbsp;&nbsp;&nbsp;
                <button className="update" onClick={() => handleUpdate(index)}>
                  Update
                </button>
                &nbsp;&nbsp;&nbsp;&nbsp;
                <button className="cancel" onClick={() => setEditIndex(-1)}>
                  Cancel
                </button>
              </div>
            ) : (
              <>
                {" "}
                <br />
                <div className="entryy">
                  {entry} &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  <button
                    className="delete"
                    onClick={() => handleDelete(index)}
                  >
                    Delete
                  </button>{" "}
                  &nbsp;&nbsp;&nbsp;&nbsp;
                  {/* <button  className="edit"  onClick={()=>handleEdit(index)}>edit data</button> */}
                  <button
                    className="edit"
                    onClick={() => handleEdit(index, entry)}
                  >
                    Edit
                  </button>{" "}
                </div>
              </>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Registry;
