import React, { Props } from "react";

export default function Card3(props) {
  return (
    <div className="container">


    <div className="row">

    <div className="col-lg-4 col-md-6">
      <div className="single_destination">
        <div className="thumb">
          <img src="assets/images/destination/5.png"  alt="" />
        </div>
        <div className="content">
          <p className="d-flex align-items-center">
            {" "}
            {/* {props.title} */}
            India
    
          </p>
        </div>
      </div>
      

      
    </div>
    <div className="col-lg-4 col-md-6">
      <div className="single_destination">
        <div className="thumb">
          <img src="assets/images/destination/5.png"  alt="" />
        </div>
        <div className="content">
          <p className="d-flex align-items-center">
            {" "}
            {/* {props.title} */}
            India
          </p>
        </div>
      </div>
      

      
    </div>
    <div className="col-lg-4 col-md-6">
      <div className="single_destination">
        <div className="thumb">
          <img src="assets/images/destination/5.png"  alt="" />
        </div>
        <div className="content">
          <p className="d-flex align-items-center">
            {" "}
            {/* {props.title} */}
            India
          </p>
        </div>
      </div>   
    </div>
  

    <div className="col-lg-4 col-md-6">
      <div className="single_destination">
        <div className="thumb">
          <img src="assets/images/destination/5.png"  alt="" />
        </div>
        <div className="content">
          <p className="d-flex align-items-center">
            {" "}
            {/* {props.title} */}
            India
          </p>
        </div>
      </div>   
    </div>
  
    <div className="col-lg-4 col-md-6">
      <div className="single_destination">
        <div className="thumb">
          <img src="assets/images/destination/5.png"  alt="" />
        </div>
        <div className="content">
          <p className="d-flex align-items-center">
            {" "}
            {/* {props.title} */}
            India
          </p>
        </div>
      </div>   
    </div>








    </div>
    </div>

 );
}




