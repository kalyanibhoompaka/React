import React, { Fragment } from "react";
import Header from "../components/Header/Header";
import Footer from "../components/Footer/Footer";
import { Link } from "react-router-dom";
import "./css/template.scss";
import "./css/bootstrap.min.scss";
import "./css/fa.min.css";
import "./css/owl.carousel.min.scss";
import "./css/style.scss";
function Contact(props) {
  let configData = props.data;
  return (
    <>
      <Header />
      
      <div ClassName="bradcam_area bradcam_bg_4" id="conk" style={{backgroundImage: `url(${configData.bgImage})`}}>
        <div ClassName="container">
          <div ClassName="row">
            <div ClassName="col-xl-12">
              <div ClassName="bradcam_text text-center">
                <h3>{configData.contacttitle}</h3>
                <p>{configData.contacdesc}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <section ClassName="contact-section">
        <div ClassName="container" id="contactk">
          <div ClassName="row">
            <div ClassName="col-12">
              <h2 ClassName="contact-title">Get in Touch</h2>
            </div>
            <div ClassName="col-lg-8">
              <form
                ClassName="form-contact contact_form"
                action="contact_process.php"
                method="post"
                id="contactForm"
                novalidate="novalidate"
              >
                <div ClassName="row">
                  <div ClassName="col-12">
                    <div ClassName="form-group">
                      <textarea
                        class="form-control w-100"
                        name="message"
                        id="message"
                        cols="30"
                        rows="9"
                        onfocus="this.placeholder = ''"
                        onblur="this.placeholder = 'Enter Message'"
                        placeholder=" Enter Message"
                      ></textarea>
                    </div>
                  </div>
                  <div ClassName="col-sm-6">
                    <div ClassName="form-group">
                      <input
                        class="form-control valid"
                        name="name"
                        id="name"
                        type="text"
                        onfocus="this.placeholder = ''"
                        onblur="this.placeholder = 'Enter your name'"
                        placeholder="Enter your name"
                      />
                    </div>
                  </div>
                  <div ClassName="col-sm-6">
                    <div ClassName="form-group">
                      <input
                        ClassName="form-control valid"
                        name="email"
                        id="email"
                        type="email"
                        onfocus="this.placeholder = ''"
                        onblur="this.placeholder = 'Enter email address'"
                        placeholder="Email"
                      />
                    </div>
                  </div>
                  <div ClassName="col-12">
                    <div ClassName="form-group">
                      <input
                        ClassName="form-control"
                        name="subject"
                        id="subject"
                        type="text"
                        onfocus="this.placeholder = ''"
                        onblur="this.placeholder = 'Enter Subject'"
                        placeholder="Enter Subject"
                      />
                    </div>
                  </div>
                </div>
                <div ClassName="form-group mt-3">
                  <button
                    type="submit"
                    ClassName="button button-contactForm boxed-btn"
                  >
                    Send
                  </button>
                </div>
              </form>
            </div>
            <div ClassName="col-lg-3 offset-lg-1">
              <div ClassName="media contact-info">
                <span ClassName="contact-info__icon">
                  <i ClassName="ti-home"></i>
                </span>
                <div ClassName="media-body">
                  <h3>{configData.adrs1}</h3>
                  <p>{configData.adrs2}</p>
                </div>
              </div>
              <div ClassName="media contact-info">
                <span ClassName="contact-info__icon">
                  <i ClassName="ti-tablet"></i>
                </span>
                <div ClassName="media-body">
                  <h3>{configData.nbrs}</h3>
                  <p>{configData.time}</p>
                </div>
              </div>
              <div ClassName="media contact-info">
                <span ClassName="contact-info__icon">
                  <i ClassName="ti-email"></i>
                </span>
                <div ClassName="media-body">
                  <h3>{configData.email}</h3>
                  <p>{configData.query}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </>
  );
}

export default Contact;
