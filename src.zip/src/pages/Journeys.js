import React, { Fragment } from "react";
import Header from "../components/Header/Header";
import Footer from "../components/Footer/Footer";
import { Link } from "react-router-dom";
import "./css/template.scss";
import "./css/bootstrap.min.scss";
import "./css/fa.min.css";
import "./css/owl.carousel.min.scss";
import "./css/style.scss";
function Journeys(props) {
  let configData = props.data;

  return (
    <>
      <Header />
      <div ClassName="container align-items-center " id="sks">
        <div ClassName="u-clearfix u-sheet u-sheet-1">
          <h2 ClassName="u-blog-control u-custom-font u-expanded-width u-heading-font u-text u-text-1">
            {configData.jorneyTitle}
          </h2>
          <br />
          <div ClassName="u-metadata u-metadata-1">
            <span ClassName="u-meta-author u-meta-icon">
              <a
                ClassName="url u-textlink"
                href="https://mgatravel.com/author/mgraham/"
                title="View all posts by Michael Graham"
              >
                <span ClassName="fn n">Michael Graham</span>
              </a>
            </span>
            <span ClassName="u-meta-category u-meta-icon">
              <a
                ClassName="u-textlink"
                href="https://mgatravel.com/category/travel/"
                rel="category tag"
              >
                Traveler's Rest
              </a>
            </span>{" "}
            <br />{" "}
          </div>
          <div ClassName="u-blog-control u-expanded-width-sm u-expanded-width-xl u-expanded-width-xs u-post-content u-text u-text-2">
            <p>
              This quote is attributed to Mr. Tim Cahill, and the idea of it is
              the backbone of our travel group known as{" "}
              <em>The Outlander Society</em> (yes, it was called that before the
              show). It sums up what I love most about travel: sharing the
              experience.
            </p>

            <p>
              As I write this on New Year’s Eve of 2020, it is bittersweet as we
              had to move all of the Outlander Society journeys to 2021 and
              2022. But we found a way to do it without disrupting our other
              planned trips for those years. So 2020 we are glad to see you in
              the rear view mirror!
            </p>

            <figure ClassName="wp-block-image size-large">
              <a href="https://mgatravel.com/outlandersociety/">
                <img
                  decoding="async"
                  width="1024"
                  height="768"
                  src="https://mgatravel.com/wp-content/uploads/2020/12/Outlander-Quote-from-Tim-Cahill-Journey-of-Friends-1024x768.jpeg"
                  alt=""
                  ClassName="wp-image-7938"
                  srcset="https://mgatravel.com/wp-content/uploads/2020/12/Outlander-Quote-from-Tim-Cahill-Journey-of-Friends-1024x768.jpeg 1024w, https://mgatravel.com/wp-content/uploads/2020/12/Outlander-Quote-from-Tim-Cahill-Journey-of-Friends-300x225.jpeg 300w, https://mgatravel.com/wp-content/uploads/2020/12/Outlander-Quote-from-Tim-Cahill-Journey-of-Friends-768x576.jpeg 768w, https://mgatravel.com/wp-content/uploads/2020/12/Outlander-Quote-from-Tim-Cahill-Journey-of-Friends-1536x1152.jpeg 1536w, https://mgatravel.com/wp-content/uploads/2020/12/Outlander-Quote-from-Tim-Cahill-Journey-of-Friends-2048x1536.jpeg 2048w, https://mgatravel.com/wp-content/uploads/2020/12/Outlander-Quote-from-Tim-Cahill-Journey-of-Friends-1200x900.jpeg 1200w"
                  sizes="(max-width: 709px) 85vw, (max-width: 909px) 67vw, (max-width: 1362px) 62vw, 840px"
                />
              </a>
            </figure>

            <p>
              Group travel offers security, opportunities to make new friends,
              share experiences and have more fun! The Outlanders Society
              travels in a small group format (16-28) people for most of our
              trips.
            </p>

            <p>The Outlander Society has only 2 simple rules:</p>

            <p ClassName="has-text-align-center">
              1. No grumpy travelers&nbsp;
              <br />
              2. No discussion of politics
            </p>

            <p>
              To become a member, you need only be invited* to go on one of our
              trips and find out why it’s more enjoyable to travel in good
              company! &nbsp;Once on the trip, simply abide by our 2 basic
              rules, and voilà – &nbsp;you will be an Outlander!&nbsp;
            </p>

            <p>
              There is a small annual fee of $100 per family. However, the fee
              will be waived if you sign up for &amp; and go on at least one
              Outlander Society trip for that or even adjacent calendar years.
              &nbsp;
            </p>

            <p>
              So you don’t have to go it alone – join us and you will find why
              it’s more enjoyable to&nbsp;travel with someone you know.
            </p>

            <p>
              And, you can check out many of our escapades over the years here
              on our YouTube
              <a
                href="https://www.youtube.com/watch?v=insZtEQsv8M&amp;list=PLdB4aatX9qkFNeJk9zBcPoLAZqgOtcqI1"
                data-type="URL"
                data-id="https://www.youtube.com/watch?v=insZtEQsv8M&amp;list=PLdB4aatX9qkFNeJk9zBcPoLAZqgOtcqI1"
              >
                playlist
              </a>
              !
            </p>

            <p>
              <em>
                *The Outlander Society Travel Club requires invitation but you
                may request to apply with&nbsp;
                <a href="https://mgatravel.com/?page_id=7292">Michael Graham</a>
                &nbsp;or ask another member to stand for you.
              </em>
            </p>
          </div>
          <div ClassName="u-container-style u-custom-color-2 u-expanded-width u-group u-group-1">
            <div ClassName="u-container-layout u-valign-middle u-container-layout-1">
              <p ClassName="u-text u-text-3">
                For more expert details on travel,{" "}
                <a
                  href="https://mgatravel.com/bestrivercruiseline/#signupform"
                  ClassName="u-active-none u-border-none u-btn u-button-link u-button-style u-hover-none u-none u-text-body-alt-color u-text-hover-custom-color-1 u-btn-1"
                >
                  sign up for our Travel Investor
                </a>
                ,&nbsp;the monthly resource with valuable travel tips, inside
                information, exclusive offers, and access to an exclusive travel
                tip video series.&nbsp;
              </p>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </>
  );
}

export default Journeys;
