import React, { Component, useState, useEffect } from "react";
import { NavLink } from "react-router-dom";
import { AccessAlarm, ThreeDRotation } from "@mui/icons-material";

class footer extends React.Component {
  render() {
    return (
      <>
        <section className="switcher-body">
          <a
            href={() => false}
            title="Prev"
            className="icon-chevron-left products-prev hidden disabled"
            style={{ display: "none" }}
          ></a>
          <div className="products-wrapper">
            <div
              className="caroufredsel_wrapper"
              style={{
                display: "block",
                text_align: "start",
                float: "none",
                position: "relative",
                inset: "auto",
                width: "1436px",
                height: "0px",
                margin: "0px",
                overflow: "hidden",
              }}
            >
              <div
                className="products-list clearfix"
                style={{
                  text_align: "left",
                  float: "none",
                  position: "absolute",
                  inset: "0px auto auto 718px",
                  margin: " 0px",
                  width: "1436px",
                  height: "0px",
                }}
              ></div>
            </div>
          </div>
          <a
            href=""
            title="Next"
            className="icon-chevron-right products-next hidden"
            style={{ display: "none" }}
          ></a>
        </section>

        {/* <header> */}
        <div className="header-area ">
          <div id="sticky-header" className="main-header-area">
            <div className="container-fluid">
              <div className="header_bottom_border">
                <div className="row align-items-center">
                  <div className="col-xl-2 col-lg-2">
                    <div className="logo">
                      <a href="index.html">
                        <img src="assets/images/logo.png" alt="" />
                      </a>
                    </div>
                  </div>
                  <div className="col-xl-8 col-lg-8">
                    <div className="main-menu  d-none d-lg-block">
                      <nav>
                        <ul id="navigation">
                          <li>
                            <link
                              rel="stylesheet"
                              href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"
                            />

                            <NavLink
                              href={() => false}
                              style={({ isActive }) => ({
                                color: isActive ? "red" : "black",
                                height: "20px",
                              })}
                              to="/home"
                            >
                              <span class="glyphicon glyphicon-home"></span>
                            </NavLink>
                          </li>
                          <li id="about">
                            <NavLink
                              href={() => false}
                              style={({ isActive }) => ({
                                color: isActive ? "red" : "black",
                              })}
                              to="/about"
                            >
                              About
                            </NavLink>
                          </li>
                          {/* <li id="about">
                            <a href="/Registration"  target="_blank" activeStyle={{ color:'red' }}>
                            Registration
                            </a>
                          </li> */}

                          <li>
                            <NavLink
                              href={() => false}
                              style={({ isActive }) => ({
                                color: isActive ? "red" : "black",
                              })}
                              to="/travel_destination"
                            >
                              Destinations
                            </NavLink>
                          </li>
                          <li>
                            <NavLink
                              href={() => false}
                              style={({ isActive }) => ({
                                backgroundImage: isActive ? "red" : "white",
                              })}
                            >
                              pages{" "}
                              <img src="assets/images/down.png" id="iconk" />
                            </NavLink>
                            <ul className="submenu">
                              <li>
                                <NavLink
                                  href={() => false}
                                  style={({ isActive }) => ({
                                    backgroundImage: isActive ? "red" : "white",
                                  })}
                                  to="/destination_details"
                                >
                                  Destinations details
                                </NavLink>
                              </li>
                            </ul>
                          </li>

                          <li>
                            <NavLink
                              href={() => false}
                              style={({ isActive }) => ({
                                color: isActive ? "red" : "black",
                              })}
                              to="/contact"
                            >
                              Contact
                            </NavLink>
                          </li>
                        </ul>
                      </nav>
                    </div>
                  </div>
                  <div class="col-xl-2 col-lg-2">
                    <div class="">
                      <div class="number">
                        <p>
                          {" "}
                          <i
                            class="fa fa-phone"
                            style={{ color: "red" }}
                          ></i>{" "}
                          (+91)8927798917
                        </p>
                      </div>
                      <div class="social_links d-none d-xl-block">
                        <ul></ul>
                      </div>
                    </div>
                  </div>

                  <div className="col-12">
                    <div className="mobile_menu d-block d-lg-none">
                      <div className="slicknav_menu">
                        <a
                          href={() => false}
                          aria-haspopup="true"
                          role="button"
                          tabindex="0"
                          className="slicknav_btn slicknav_collapsed"
                          style={{ outline: "none" }}
                        >
                          <span className="slicknav_menutxt">MENU</span>
                          <span className="slicknav_icon">
                            <span className="slicknav_icon-bar"></span>
                            <span className="slicknav_icon-bar"></span>
                            <span className="slicknav_icon-bar"></span>
                          </span>
                        </a>
                        <ul
                          className="slicknav_nav slicknav_hidden"
                          aria-hidden="true"
                          role="menu"
                          style={{ display: "none" }}
                        >
                          <li>
                            <a
                              className="active"
                              href="index.html"
                              role="menuitem"
                              tabindex="-1"
                              activeStyle={{ color: "red" }}
                            >
                              home
                            </a>
                          </li>
                          <li>
                            <a
                              href="about.html"
                              role="menuitem"
                              tabindex="-1"
                              activeStyle={{ color: "red" }}
                            >
                              About
                            </a>
                          </li>
                          <li>
                            <a
                              className=""
                              href="/travel_destination"
                              role="menuitem"
                              tabindex="-1"
                              activeStyle={{ color: "red" }}
                            >
                              Destination
                            </a>
                          </li>
                          <li className="slicknav_collapsed slicknav_parent">
                            <a
                              href={() => false}
                              role="menuitem"
                              aria-haspopup="true"
                              tabindex="-1"
                              className="slicknav_item slicknav_row"
                              style={{ outline: "none" }}
                            >
                              <a href={() => false} tabindex="-1">
                                pages <i className="ti-angle-down"></i>
                              </a>
                              <span className="slicknav_arrow">+</span>
                            </a>
                            <ul
                              className="submenu slicknav_hidden"
                              role="menu"
                              aria-hidden="true"
                              style={{ display: "none" }}
                            >
                              <li>
                                <a
                                  href="/destination_details"
                                  role="menuitem"
                                  tabindex="-1"
                                  activeStyle={{ color: "red" }}
                                >
                                  Destinations details
                                </a>
                              </li>
                              <li>
                                <a
                                  href="elements.html"
                                  role="menuitem"
                                  tabindex="-1"
                                >
                                  elements
                                </a>
                              </li>
                            </ul>
                          </li>
                          <li className="slicknav_collapsed slicknav_parent">
                            <a
                              href={() => false}
                              role="menuitem"
                              aria-haspopup="true"
                              tabindex="-1"
                              className="slicknav_item slicknav_row"
                              style={{ outline: "none" }}
                            >
                              <a href={() => false} tabindex="-1">
                                blog <i className="ti-angle-down"></i>
                              </a>
                              <span className="slicknav_arrow">+</span>
                            </a>
                            <ul
                              className="submenu slicknav_hidden"
                              role="menu"
                              aria-hidden="true"
                              style={{ display: "none" }}
                            >
                              <li>
                                <a
                                  href="blog.html"
                                  role="menuitem"
                                  tabindex="-1"
                                >
                                  blog
                                </a>
                              </li>
                              <li>
                                <a
                                  href="single-blog.html"
                                  role="menuitem"
                                  tabindex="-1"
                                >
                                  single-blog
                                </a>
                              </li>
                            </ul>
                          </li>
                          <li>
                            <a
                              href="contact.html"
                              role="menuitem"
                              tabindex="-1"
                            >
                              Contact
                            </a>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* </header> */}

        {/* <div class="modal fade custom_search_pop show" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" style={{padding_right: '17px', display: 'block'}}>
<div class="modal-dialog modal-dialog-centered" role="document">
<div class="modal-content">
<div class="serch_form">
<input type="text" placeholder="Search" />
<button type="submit">search</button>
</div>
</div>
</div>
</div> */}
      </>
    );
  }
}

export default footer;
