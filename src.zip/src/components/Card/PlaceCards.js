import React, { Props } from "react";

export default function PlaceCard(props) {
  return (
    <div className="col-lg-4 col-md-6">
      <div className="single_place">
        <div className="thumb">
          <img src={props.imagePath} alt="" />
          <a href={() => false} className="prise">
            $500
          </a>
        </div>
        <div className="place_info">
          <a href="/destination_details">
            <h3>{props.title}</h3>
          </a>
          <p>United State of America</p>
          <div className="rating_days d-flex justify-content-between">
            <span className="d-flex justify-content-center align-items-center">
              <i className="fa fa-star"></i>
              <i className="fa fa-star"></i>
              <i className="fa fa-star"></i>
              <i className="fa fa-star"></i>
              <i className="fa fa-star"></i>
              <a href={() => false}>(20 Review)</a>
            </span>
            <div className="days">
              <i className="fa fa-clock-o"></i>
              <a href={() => false}>5 Days</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
