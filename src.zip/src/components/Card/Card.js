import React, { Props } from "react";
import { NavLink } from "react-router-dom";

export default function Card(props) {

  return (
   
    <div className="col-lg-4 col-md-6">
      <div className="single_destination">
        <div className="thumb">
          <img src={props.imagePath} alt="" />
        </div>
        <div className="content">
          <p className="d-flex align-items-center">
            {" "}
            {props.title}
            <NavLink
              href={() => false}
              style={({ isActive }) => ({
                color: isActive ? "red" : "black",
              })}
              to={props.link}
            >
              {props.linktitle}
            </NavLink>
            {/* <a href={props.link}>{props.linktitle}</a> */}{" "}
          </p>
        </div>
      </div>
    </div>

  );
}

// const root = ReactDOM.createRoot(document.getElementById('root'));
// const element = <Welcome name="Sara" />;
// root.render(element);

//     export default Card;
