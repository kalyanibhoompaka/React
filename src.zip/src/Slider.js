import React, { useState } from "react";
import PropTypes from "prop-types";
import styled from "styled-components";

import Status from "./Status";

const Text = styled.p`
  max-width: 500px;
  margin-right:30%;
  margin-left:30%;
  font-family: "Nothing You Could Do", cursive;
  font-size: 60px;
  margin-top:30px;
`;
const Avatar = styled.img`
  width: 100%;
  height: 100%;
`;
const Content = styled.div`
  display: flex;
  flex-direction: column;
  text-align: center;
  max-width: 100%;
`;

const Slider = ({ data, activeIndex }) => {
  return (
    <Content>
      {data.map((s, index) => (
        <div
          className={index === activeIndex ? "active" : "inactive"}
          key={index}
        >



          <Avatar src={s.pic} style={{width:'100%'}}/>
          <Text style={{margin_left: '30%', margin_right: '30%'}}  >{s.text}</Text>


          
        </div>
      ))}
      <Status active={activeIndex} data={data} />
    </Content>
  );
};

Slider.propTypes = {
  data: PropTypes.array,
  activeIndex: PropTypes.number
};

export default Slider;
